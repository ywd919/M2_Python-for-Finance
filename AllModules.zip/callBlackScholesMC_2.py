from BlackScholesMC_2 import blackScholesMonteCarlo

numPaths = 50000 
s0 = 100.0
k = 100.0
T=1.0
r=0.05 
sigma = 0.20

price = blackScholesMonteCarlo(numPaths,s0,k,T,r,sigma)
print(price)
