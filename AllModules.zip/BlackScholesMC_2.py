import numpy as np

###############################################################################

def blackScholesMonteCarlo(numPaths,s0,k,T,r,sigma):

    payoff = 0.0
    for i in range(1,numPaths):
        z = np.random.normal(0.0,1.0)
        sT = s0 * np.exp((r-0.5*sigma**2) * T + sigma * np.sqrt(T) * z)
        payoff += max(sT-k,0)
        
    value = np.exp(-r*T) * payoff/numPaths
    
    return value    

###############################################################################

if __name__ == "__main__":

    numPaths = 50000 
    s0 = 100.0
    k = 100.0
    T=1.0
    r=0.05 
    sigma = 0.20
    
    price = blackScholesMonteCarlo(numPaths,s0,k,T,r,sigma)
    
    print(price)
