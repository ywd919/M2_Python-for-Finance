import numpy as np

###############################################################################

def flowTimes(maturity, frequency):
    small = 1e-10
    numPaymentsMinusOne = int(maturity * frequency-small)
    firstPayment = maturity - numPaymentsMinusOne / frequency
    return np.linspace(firstPayment,maturity,numPaymentsMinusOne+1)

###############################################################################

if __name__ == "__main__":
    print(flowTimes(10,2))
    print(flowTimes(5,4))
    print(flowTimes(10,1))
    print(flowTimes(9.7,1))
    print(flowTimes(9.4,1))
