###############################################################################
# Dominic O'Kane EDHEC 2021
###############################################################################

from HelperFunctions import flowTimes
import scipy.optimize as optimize
from datetime import date

DAYS_IN_YEAR = 365.242

class Bond():
    
    def __init__(self, maturity_date, coupon, frequency):
        self._maturity_date = maturity_date
        self._coupon = coupon
        self._frequency = frequency
    
    def fullPriceFromYield(self, value_date, yld):   
        years = abs(self._maturity_date - value_date).days / DAYS_IN_YEAR
        paymentTimes = flowTimes(years, self._frequency)    

        price = 0.0            
        for t in paymentTimes:
            df = 1.0/(1.0 + yld/self._frequency)**(t*self._frequency)
            price += ( self._coupon / self._frequency ) * df            
        price += df # par         
        return price

    def cleanPriceFromYield(self, value_date, yld):   
        full_price = self.fullPriceFromYield(value_date, yld)  
        clean_price = full_price - self.accruedInterest(value_date, )
        return clean_price

    def fullPriceFromYieldSolver(self, yld, *args):        
        value_date = args[0]
        mkt_full_price = args[1]
        full_price = self.fullPriceFromYield(value_date, yld) - mkt_full_price
        return full_price
        
    def yieldFromCleanPrice(self, value_date, clean_price, guess=0.05):
        full_price = clean_price  + self.accruedInterest(value_date)
        argsv = (value_date, full_price,)
        return optimize.newton(self.fullPriceFromYieldSolver, guess, args = argsv)
    
    def accruedInterest(self, value_date):
        years = abs(self._maturity_date - value_date).days / DAYS_IN_YEAR
        paymentTimes = flowTimes(years, self._frequency)    
        accruedPeriod = 1.0/self._frequency - paymentTimes[0]
        return accruedPeriod * self._coupon

    def __str__(self):
        # This is what you see when you print this object
         newline = '\n'
         s = "Bond:" + newline
         s += "Maturity: " + str(self._maturity_date) + newline
         s += "Coupon: " + str(self._coupon) + newline
         s += "Frequency: " + str(self._frequency) + newline
         return s


##################################################################

if __name__ == "__main__":

    maturity_date = date(2016, 10, 25)
    cpn = 0.05
    freq = 1
    bond = Bond(maturity_date, cpn, freq)
    print(bond)

    value_date = date(2011, 10, 11)    
    yld = 0.05
    full_price = bond.fullPriceFromYield(value_date, yld)
    print('Full Price:', full_price)

    clean_price = bond.cleanPriceFromYield(value_date, yld)
    print('Clean Price:', clean_price)
    accd = bond.accruedInterest(value_date)
    print("Accrued:", accd)
    
    print("Implying out the bond yield")
    clean_price = 1.1462    
    yld = bond.yieldFromCleanPrice(value_date, clean_price)
    print('Yield:', yld)    
        
