# -*- coding: utf-8 -*-
"""
Created on Thu Oct 19 02:17:57 2017

@author: Dominic
"""

from datetime import date
from Option import Option
import matplotlib.pyplot as plt

expiry_date = date(2022, 6, 1)
stockPrice = 100
volatility = 0.30
interest_rate = 0.05
dividend_yield = 0.0

stockPrices = range(50,150)
callOptionValues = []
putOptionValues = []
value_date = date(2022, 1, 1)

for stockPrice in stockPrices:
    callOption = Option(expiry_date, 100.0, "CALL")
    value = callOption.value(value_date, stockPrice, interest_rate, dividend_yield, volatility)
    callOptionValues.append(value)

for stockPrice in stockPrices:
    putOption = Option(expiry_date, 100.0, "PUT")
    value = putOption.value(value_date, stockPrice, interest_rate, dividend_yield, volatility)
    putOptionValues.append(value)

plt.figure()
plt.plot(stockPrices, callOptionValues, color = 'b', label="Call Option")
plt.plot(stockPrices, putOptionValues, color = 'r', label = "Put Option")
plt.xlabel("Stock Price")
plt.legend(loc='best')

callOption = Option(expiry_date, 100.0, "CALL")
value = callOption.value(value_date, stockPrice, dividend_yield, volatility, interest_rate)
impliedVol = callOption.impliedVolatility(value_date, value, stockPrice, dividend_yield, 
                                          interest_rate)
print("Implied Vol %9.5f" % impliedVol) 
