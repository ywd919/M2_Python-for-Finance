###############################################################################

PI = 3.14159

class Circle ():
    def __init__(self, radius = 1):
        print("Creating circle")
        self._radius = radius
        
    def area(self):
        a = PI * self._radius**2
        return a

    def perimeter(self):
        return 2.0 * PI * self._radius
    
    def setRadius(self, r): # Add some validation below
        self._radius = r

###############################################################################

if __name__ == "__main__":

    print('Circle')
    c = Circle(2)
    print(c.area())
    print(c.perimeter())
    c.setRadius(4)
    print(c.area())
