# -*- coding: utf-8 -*-
"""
Created on Thu Oct 19 02:17:57 2017

@author: Dominic
"""

#import FinUtils
from math import exp, log, sqrt
from scipy import optimize
from scipy.stats import norm
from datetime import date

DAYS_IN_YEAR = 365.242

###############################################################################

def f(volatility, *args):

    self = args[0]
    valueDate = args[1]
    stockPrice = args[2]
    divYield = args[3]
    interestRate = args[4]
    value = args[5]

    objFn = self.value(valueDate,stockPrice,divYield,volatility,interestRate) - value

    return objFn

###############################################################################

class Option(object):

    def __init__ (self, expiry_date, strike_price, option_type ):

        if isinstance(expiry_date, date) == False:        
            print("Expiry date is not a date")

        self._expiry_date = expiry_date
        self._strike_price = float(strike_price)
        self._option_type = option_type.upper()
        
        if self._option_type != "CALL" and self._option_type != "PUT":
            print("Unknown option type")

###############################################################################

    def value(self, value_date, stock_price, interest_rate, 
              dividend_yield, volatility ):

        t = abs(self._expiry_date - value_date).days / DAYS_IN_YEAR
        r = interest_rate; q = dividend_yield; s = stock_price; 
        k = self._strike_price; v = volatility
        
        d1 = (log(s/k) + (r - q + v*v / 2.0) * t) / (v * sqrt(t))
        d2 = (log(s/k) + (r - q - v*v / 2.0) * t) / (v * sqrt(t))

        if self._option_type == "CALL":
            v = s * exp(-q * t) * norm.cdf(d1)
            v = v - k * exp(-r * t) * norm.cdf(d2)
        elif self._option_type == "PUT":
            v = k * exp(-r * t) * norm.cdf(-d2)
            v = v - s * exp(-q * t) * norm.cdf(-d1)

        return v

###############################################################################

    def impliedVolatility(self, value_date, option_mkt_value, stock_price,
                          dividend_yield, interest_rate):

        argtuple = (self, value_date, stock_price, dividend_yield, 
                    interest_rate, option_mkt_value)

        sigma = optimize.newton(f,x0=0.2, args=argtuple, tol=1e-8, maxiter=50)
        return sigma

###############################################################################

if __name__ == "__main__":
    
    import matplotlib.pyplot as plt

    expiry_date = 10; # date(2022, 6, 1)
    stockPrice = 100
    volatility = 0.30
    interest_rate = 0.05
    dividend_yield = 0.0

    stockPrices = range(50,150)
    callOptionValues = []
    putOptionValues = []
    value_date = date(2022, 1, 1)

    for stockPrice in stockPrices:
        callOption = Option(expiry_date, 100.0, "CALL")
        value = callOption.value(value_date, stockPrice, interest_rate, dividend_yield, volatility)
        callOptionValues.append(value)

    for stockPrice in stockPrices:
        putOption = Option(expiry_date, 100.0, "PUT")
        value = putOption.value(value_date, stockPrice, interest_rate, dividend_yield, volatility)
        putOptionValues.append(value)

    plt.figure()
    plt.plot(stockPrices, callOptionValues, color = 'b', label="Call Option")
    plt.plot(stockPrices, putOptionValues, color = 'r', label = "Put Option")
    plt.xlabel("Stock Price")
    plt.legend(loc='best')

    callOption = Option(expiry_date, 100.0, "CALL")
    value = callOption.value(value_date, stockPrice, dividend_yield, volatility, interest_rate)
    impliedVol = callOption.impliedVolatility(value_date, value, stockPrice, dividend_yield, 
                                              interest_rate)
    print("Implied Vol %9.5f" % impliedVol) 
